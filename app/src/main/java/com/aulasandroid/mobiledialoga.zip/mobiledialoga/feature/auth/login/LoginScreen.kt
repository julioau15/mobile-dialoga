package com.aulasandroid.mobiledialoga.feature.auth.login

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aulasandroid.mobiledialoga.components.DialogaTextLink
import com.aulasandroid.mobiledialoga.data.useAuth
import com.aulasandroid.mobiledialoga.feature.auth.legal.DocumentoLegalDialog
import com.aulasandroid.mobiledialoga.feature.auth.legal.TipoDocumento
import com.aulasandroid.mobiledialoga.feature.auth.login.components.LoginForm
import com.aulasandroid.mobiledialoga.feature.auth.login.components.LoginHero
import com.aulasandroid.mobiledialoga.ui.theme.CorFundoLogin
import com.aulasandroid.mobiledialoga.ui.theme.CorPrimaria
import com.aulasandroid.mobiledialoga.ui.theme.CorSecundaria
import com.aulasandroid.mobiledialoga.ui.theme.MobileDialogaTheme


@Composable
fun LoginScreen(
    onCadastrar: () -> Unit,
    onEsqueciSenha: () -> Unit,
    onLoginSuccess: (String) -> Unit,
    onProfissionalEmAnalise: () -> Unit,
    onCadastrarComGoogle: (String, String, String?, String?) -> Unit,
    viewModel: LoginViewModel = viewModel()
) {
    val estado by viewModel.uiState.observeAsState(LoginUiState())
    val authState = useAuth()
    val context = LocalContext.current
    var documentoAberto by rememberSaveable { mutableStateOf<TipoDocumento?>(null) }

    documentoAberto?.let { tipo ->
        DocumentoLegalDialog(tipo = tipo, onFechar = { documentoAberto = null })
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CorFundoLogin)
            .systemBarsPadding()
            .imePadding()
    ) {
        // ---------- Conteúdo principal (rolável) ----------
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(48.dp))

            LoginHero(modifier = Modifier.fillMaxWidth())

            Spacer(modifier = Modifier.height(24.dp))

            if (estado.erroGeral != null) {
                Text(
                    text = estado.erroGeral!!,
                    color = Color.Red,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
            }

            LoginForm(
                estado = estado,
                onEmailChange = viewModel::onEmailChange,
                onSenhaChange = viewModel::onSenhaChange,
                onEsqueciSenha = onEsqueciSenha,
                onEntrar = { viewModel.entrar(authState, onLoginSuccess, onProfissionalEmAnalise) },
                onEntrarComGoogle = {
                    viewModel.entrarComGoogle(context, authState, onLoginSuccess, onProfissionalEmAnalise, onCadastrarComGoogle)
                },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(40.dp))

            DialogaTextLink(texto = "Não tem conta?", link = "Cadastre-se", onClick = onCadastrar)

            Spacer(modifier = Modifier.height(24.dp))
        }

        // ---------- Rodapé ----------
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Termos de Uso",
                color = CorPrimaria,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .clickable { documentoAberto = TipoDocumento.TERMOS_DE_USO }
                    .padding(horizontal = 6.dp, vertical = 8.dp)
            )
            Text(text = "|", color = CorSecundaria, fontSize = 13.sp)
            Text(
                text = "Política de Privacidade",
                color = CorPrimaria,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .clickable { documentoAberto = TipoDocumento.POLITICA_DE_PRIVACIDADE }
                    .padding(horizontal = 6.dp, vertical = 8.dp)
            )
        }
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun LoginScreenPreview() {
    MobileDialogaTheme {
        LoginScreen(onCadastrar = {}, onEsqueciSenha = {}, onLoginSuccess = {}, onProfissionalEmAnalise = {}, onCadastrarComGoogle = { _, _, _, _ -> })
    }
}
