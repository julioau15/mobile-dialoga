package com.aulasandroid.mobiledialoga.feature.auth.login

import android.content.Context
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aulasandroid.mobiledialoga.core.error.ErrorTranslator
import com.aulasandroid.mobiledialoga.core.validation.EmailValidator
import com.aulasandroid.mobiledialoga.data.AuthException
import com.aulasandroid.mobiledialoga.data.AuthState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch


class LoginViewModel : ViewModel() {

    private val _uiState = MutableLiveData(LoginUiState())
    val uiState: LiveData<LoginUiState> = _uiState

    private val estado: LoginUiState get() = _uiState.value ?: LoginUiState()

    fun onEmailChange(email: String) {
        _uiState.value = estado.copy(email = email.trim(), erroEmail = null, erroGeral = null)
    }

    fun onSenhaChange(senha: String) {
        _uiState.value = estado.copy(senha = senha, erroSenha = null, erroGeral = null)
    }

    fun entrar(authState: AuthState, onLoginSuccess: (String) -> Unit, onProfissionalEmAnalise: () -> Unit) {
        val erroEmail = EmailValidator.validar(estado.email)
        val erroSenha = if (estado.senha.isEmpty()) "Informe a senha" else null
        _uiState.value = estado.copy(erroEmail = erroEmail, erroSenha = erroSenha, erroGeral = null)
        if (erroEmail != null || erroSenha != null) return

        viewModelScope.launch {
            _uiState.value = estado.copy(isLoading = true, erroGeral = null)
            try {
                val auth = authState.login(estado.email, estado.senha)
                _uiState.value = estado.copy(isLoading = false)
                onLoginSuccess(auth.nivel)
            } catch (e: AuthException) {
                val lowerMsg = (e.message ?: "").lowercase()
                if (e.codigo == "PROFISSIONAL_EM_ANALISE" || e.codigo == "PROFISSIONAL_RECUSADO" ||
                    lowerMsg.contains("análise") || lowerMsg.contains("analise") ||
                    lowerMsg.contains("aprovação") || lowerMsg.contains("aprovacao") ||
                    lowerMsg.contains("pendente") || lowerMsg.contains("aguardando")) {
                    _uiState.value = estado.copy(isLoading = false)
                    onProfissionalEmAnalise()
                } else {
                    _uiState.value = estado.copy(
                        isLoading = false,
                        erroGeral = ErrorTranslator.traduzirLogin(e.message)
                    )
                }
            } catch (e: Exception) {
                val lowerMsg = (e.message ?: "").lowercase()
                if (lowerMsg.contains("análise") || lowerMsg.contains("analise") ||
                    lowerMsg.contains("aprovação") || lowerMsg.contains("aprovacao") ||
                    lowerMsg.contains("pendente") || lowerMsg.contains("aguardando")) {
                    _uiState.value = estado.copy(isLoading = false)
                    onProfissionalEmAnalise()
                } else {
                    _uiState.value = estado.copy(
                        isLoading = false,
                        erroGeral = ErrorTranslator.traduzirLogin(e.message)
                    )
                }
            }
        }
    }

    fun entrarComGoogle(
        context: Context,
        authState: AuthState,
        onLoginSuccess: (String) -> Unit,
        onProfissionalEmAnalise: () -> Unit,
        onCadastrarComGoogle: (String, String, String?, String?) -> Unit
    ) {
        if (estado.isLoading || estado.isGoogleLoading) return
        viewModelScope.launch {
            _uiState.value = estado.copy(isGoogleLoading = true, erroGeral = null)
            val googleData = try {
                GoogleSignIn.obterDadosGoogle(context)
            } catch (e: GetCredentialCancellationException) {
                _uiState.value = estado.copy(isGoogleLoading = false)
                return@launch
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _uiState.value = estado.copy(isGoogleLoading = false, escolherContaDoAparelho = true)
                return@launch
            }
            concluirLoginGoogle(googleData, authState, onLoginSuccess, onProfissionalEmAnalise, onCadastrarComGoogle)
        }
    }

    fun seletorDeContasAberto() {
        _uiState.value = estado.copy(escolherContaDoAparelho = false)
    }

    fun contaDoAparelhoEscolhida(
        email: String?,
        authState: AuthState,
        onLoginSuccess: (String) -> Unit,
        onProfissionalEmAnalise: () -> Unit,
        onCadastrarComGoogle: (String, String, String?, String?) -> Unit
    ) {
        if (email.isNullOrBlank()) {
            _uiState.value = estado.copy(isGoogleLoading = false, escolherContaDoAparelho = false)
            return
        }
        viewModelScope.launch {
            _uiState.value = estado.copy(isGoogleLoading = true, erroGeral = null, escolherContaDoAparelho = false)
            concluirLoginGoogle(
                GoogleSignIn.dadosDaContaDoAparelho(email),
                authState, onLoginSuccess, onProfissionalEmAnalise, onCadastrarComGoogle
            )
        }
    }

    private suspend fun concluirLoginGoogle(
        googleData: GoogleUserData,
        authState: AuthState,
        onLoginSuccess: (String) -> Unit,
        onProfissionalEmAnalise: () -> Unit,
        onCadastrarComGoogle: (String, String, String?, String?) -> Unit
    ) {
        try {
            val auth = try {
                authState.loginGoogle(googleData.idGoogle, googleData.email)
            } catch (e: AuthException) {
                val msg = (e.message ?: "").lowercase()
                val emAnalise = e.codigo == "PROFISSIONAL_EM_ANALISE" || e.codigo == "PROFISSIONAL_RECUSADO" ||
                    msg.contains("análise") || msg.contains("analise")
                val semCadastro = e.codigo == "USUARIO_NAO_ENCONTRADO" ||
                    msg.contains("não cadastrado") || msg.contains("nao cadastrado") ||
                    msg.contains("não encontrado") || msg.contains("nao encontrado")

                _uiState.value = estado.copy(isGoogleLoading = false)
                when {
                    emAnalise -> onProfissionalEmAnalise()
                    semCadastro -> onCadastrarComGoogle(googleData.idGoogle, googleData.email, googleData.nome, googleData.fotoUrl)
                    else -> _uiState.value = estado.copy(
                        isGoogleLoading = false,
                        erroGeral = ErrorTranslator.traduzirLogin(e.message)
                    )
                }
                return
            }
            _uiState.value = estado.copy(isGoogleLoading = false)
            onLoginSuccess(auth.nivel)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            _uiState.value = estado.copy(
                isGoogleLoading = false,
                erroGeral = ErrorTranslator.traduzirLogin(e.message)
            )
        }
    }
}
