package com.aulasandroid.mobiledialoga.feature.auth.cadastro

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.aulasandroid.mobiledialoga.components.MascaraCrp
import com.aulasandroid.mobiledialoga.core.error.ErrorTranslator
import com.aulasandroid.mobiledialoga.core.validation.EmailValidator
import com.aulasandroid.mobiledialoga.core.validation.PasswordValidator
import com.aulasandroid.mobiledialoga.core.validation.PhoneValidator
import com.aulasandroid.mobiledialoga.data.remote.RetrofitFactory
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

/**
 * ViewModel responsável pelo fluxo de cadastro de Pacientes e Profissionais.
 */
class CadastroViewModel : ViewModel() {

    private val _uiState = MutableLiveData(CadastroUiState())
    val uiState: LiveData<CadastroUiState> = _uiState

    private val estado: CadastroUiState get() = _uiState.value ?: CadastroUiState()

    init {
        carregarEspecialidades()
    }

    fun carregarEspecialidades() {
        RetrofitFactory().getEspecialidadeService().listarEspecialidades().enqueue(object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                if (response.isSuccessful) {
                    val json = response.body()
                    val respObj = json?.getAsJsonObject("response")
                    val array = respObj?.getAsJsonArray("especialidade")
                        ?: json?.getAsJsonArray("response")
                        ?: respObj?.getAsJsonArray("especialidades")

                    val list = mutableListOf<EspecialidadeDto>()
                    if (array != null) {
                        for (element in array) {
                            val item = element.asJsonObject
                            list.add(
                                EspecialidadeDto(
                                    item.get("id").asInt,
                                    if (item.has("especialidade")) item.get("especialidade").asString else item.get("nome").asString
                                )
                            )
                        }
                    }
                    _uiState.value = estado.copy(especialidadesList = list)
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {}
        })
    }

    fun onTipoContaChange(tipo: TipoConta) {
        _uiState.value = estado.copy(tipoConta = tipo, erroEspecialidade = null, erroCpf = null, erroCrp = null, erroGeral = null)
    }

    fun onNomeChange(nome: String) {
        _uiState.value = estado.copy(nome = nome, erroNome = null, erroGeral = null)
    }

    fun onEmailChange(email: String) {
        _uiState.value = estado.copy(email = email.trim().lowercase(), erroEmail = null, erroGeral = null)
    }

    fun onCelularChange(celular: String) {
        _uiState.value = estado.copy(celular = PhoneValidator.limpar(celular), erroCelular = null, erroGeral = null)
    }

    fun onCpfChange(cpf: String) {
        val limpo = cpf.filter { it.isDigit() }.take(11)
        _uiState.value = estado.copy(cpf = limpo, erroCpf = null, erroGeral = null)
    }

    fun onCrpChange(crp: String) {
        _uiState.value = estado.copy(crp = crp.uppercase(), erroCrp = null, erroGeral = null)
    }

    fun onInstituicaoChange(instituicao: String) {
        _uiState.value = estado.copy(instituicaoClinica = instituicao, erroGeral = null)
    }

    fun onEspecialidadeToggle(especialidadeNome: String) {
        val atuais = estado.especialidadesSelecionadas.toMutableList()
        if (atuais.contains(especialidadeNome)) {
            atuais.remove(especialidadeNome)
        } else {
            atuais.add(especialidadeNome)
        }
        _uiState.value = estado.copy(
            especialidadesSelecionadas = atuais,
            especialidade = atuais.firstOrNull(),
            erroEspecialidade = null,
            erroGeral = null
        )
    }

    fun onEspecialidadeChange(especialidade: String) {
        onEspecialidadeToggle(especialidade)
    }

    fun continuar() {
        val atual = estado
        val nomeLimpo = atual.nome.trim()
        val partesNome = nomeLimpo.split("\\s+".toRegex()).filter { it.isNotBlank() }
        val erroNome = when {
            nomeLimpo.isBlank() -> "Informe seu nome completo"
            partesNome.size < 2 -> "Informe seu nome completo (ex: Julio Augusto)"
            else -> null
        }

        val erroCpf = if (atual.tipoConta == TipoConta.PROFISSIONAL && atual.cpf.length < 11) "CPF inválido" else null
        val erroCrp = if (atual.tipoConta == TipoConta.PROFISSIONAL && atual.crp.isBlank()) "Informe seu CRP" else null
        val erroEspecialidade = if (atual.tipoConta == TipoConta.PROFISSIONAL && atual.especialidadesSelecionadas.isEmpty()) {
            "Selecione ao menos uma especialidade"
        } else null

        val validado = atual.copy(
            erroNome = erroNome,
            erroEmail = EmailValidator.validar(atual.email),
            erroCelular = PhoneValidator.validar(atual.celular),
            erroCpf = erroCpf,
            erroCrp = erroCrp,
            erroEspecialidade = erroEspecialidade,
            erroGeral = null
        )
        val temErro = listOf(
            validado.erroNome, validado.erroEmail, validado.erroCelular,
            validado.erroCpf, validado.erroCrp, validado.erroEspecialidade
        ).any { it != null }

        if (temErro) {
            _uiState.value = validado
            return
        }

        _uiState.value = validado.copy(isLoading = true, erroGeral = null)

        val cpfArg = if (atual.tipoConta == TipoConta.PROFISSIONAL) atual.cpf else null
        val crpArg = if (atual.tipoConta == TipoConta.PROFISSIONAL && atual.crp.isNotBlank()) MascaraCrp.formatarCrp(atual.crp) else null

        RetrofitFactory().getAuthService().verificarCadastro(
            email = atual.email,
            celular = atual.celular,
            cpf = cpfArg,
            crp = crpArg
        ).enqueue(object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                val json = if (response.isSuccessful) {
                    response.body()
                } else {
                    val errorStr = response.errorBody()?.string()
                    if (!errorStr.isNullOrBlank()) {
                        try { JsonParser().parse(errorStr).asJsonObject } catch (e: Exception) { null }
                    } else null
                }

                val isOk = response.isSuccessful || (json?.has("status") == true && json.get("status").asBoolean)

                if (isOk) {
                    _uiState.value = estado.copy(isLoading = false, etapa = EtapaCadastro.SENHA, erroGeral = null)
                } else {
                    val rawMsg = if (json != null && json.has("message")) {
                        json.get("message").asString
                    } else if (json != null && json.has("erro")) {
                        json.get("erro").asString
                    } else {
                        "Os dados informados já estão cadastrados no sistema."
                    }
                    val msg = ErrorTranslator.traduzirCadastro(rawMsg)
                    val lowerMsg = rawMsg.lowercase()
                    val erroEmail = if (lowerMsg.contains("e-mail") || lowerMsg.contains("email")) msg else null
                    val erroCelular = if (lowerMsg.contains("celular")) msg else null
                    val erroCpf = if (lowerMsg.contains("cpf")) msg else null
                    val erroCrp = if (lowerMsg.contains("crp")) msg else null

                    _uiState.value = estado.copy(
                        isLoading = false,
                        erroEmail = erroEmail ?: estado.erroEmail,
                        erroCelular = erroCelular ?: estado.erroCelular,
                        erroCpf = erroCpf ?: estado.erroCpf,
                        erroCrp = erroCrp ?: estado.erroCrp,
                        erroGeral = if (erroEmail == null && erroCelular == null && erroCpf == null && erroCrp == null) msg else null
                    )
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                _uiState.value = estado.copy(isLoading = false, etapa = EtapaCadastro.SENHA, erroGeral = null)
            }
        })
    }

    fun onSenhaChange(senha: String) {
        _uiState.value = estado.copy(senha = senha, erroSenha = null, erroGeral = null)
    }

    fun onConfirmacaoChange(confirmacao: String) {
        _uiState.value = estado.copy(confirmacao = confirmacao, erroConfirmacao = null, erroGeral = null)
    }

    fun preencherDadosGoogle(idGoogle: String, email: String, nome: String?, fotoUrl: String?) {
        _uiState.value = estado.copy(
            idGoogle = idGoogle,
            email = email.trim().lowercase(),
            nome = nome ?: "",
            fotoUrl = fotoUrl,
            etapa = EtapaCadastro.DADOS_PESSOAIS,
            isLoading = false,
            erroEmail = null,
            erroNome = null,
            erroGeral = null
        )
    }

    /**
     * Realiza o cadastro enviando Multipart RequestBody para a API (exatamente como o backend espera).
     */
    fun criarConta(onPacienteCadastrado: () -> Unit) {
        val atual = estado
        val erroSenha = PasswordValidator.validar(atual.senha)
        val erroConfirmacao = PasswordValidator.validarConfirmacao(atual.senha, atual.confirmacao)
        _uiState.value = atual.copy(erroSenha = erroSenha, erroConfirmacao = erroConfirmacao, erroGeral = null)
        if (erroSenha != null || erroConfirmacao != null) return

        _uiState.value = estado.copy(isLoading = true, erroGeral = null)

        val mediaType = "text/plain".toMediaTypeOrNull()
        val idGoogleBody = if (!atual.idGoogle.isNullOrBlank()) RequestBody.create(mediaType, atual.idGoogle) else null
        val fotoAvatarBody = if (!atual.fotoUrl.isNullOrBlank()) RequestBody.create(mediaType, atual.fotoUrl) else null

        if (atual.tipoConta == TipoConta.PACIENTE) {
            val nomeBody = RequestBody.create(mediaType, atual.nome)
            val emailBody = RequestBody.create(mediaType, atual.email)
            val celularBody = RequestBody.create(mediaType, atual.celular)
            val senhaBody = RequestBody.create(mediaType, atual.senha)

            RetrofitFactory().getPacienteService().cadastrarPaciente(nomeBody, emailBody, celularBody, senhaBody, idGoogleBody, fotoAvatarBody)
                .enqueue(object : Callback<JsonObject> {
                    override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                        val json = if (response.isSuccessful) {
                            response.body()
                        } else {
                            val errorStr = response.errorBody()?.string()
                            if (!errorStr.isNullOrBlank()) {
                                try { JsonParser().parse(errorStr).asJsonObject } catch (e: Exception) { null }
                            } else null
                        }

                        val isSuccess = response.isSuccessful || (json?.has("status") == true && json.get("status").asBoolean)
                        if (isSuccess) {
                            reiniciar()
                            onPacienteCadastrado()
                        } else {
                            val rawMsg = json?.get("message")?.asString ?: json?.get("erro")?.asString
                            val msg = ErrorTranslator.traduzirCadastro(rawMsg)
                            _uiState.value = estado.copy(isLoading = false, erroGeral = msg)
                        }
                    }

                    override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                        _uiState.value = estado.copy(
                            isLoading = false,
                            erroGeral = ErrorTranslator.traduzirCadastro(t.message)
                        )
                    }
                })
        } else {
            val selectedEspIds = estado.especialidadesSelecionadas.mapNotNull { nome ->
                estado.especialidadesList.find { it.nome == nome }?.id
            }
            val finalEspIds = if (selectedEspIds.isNotEmpty()) selectedEspIds else listOf(1)
            val espJson = finalEspIds.toString()

            val crpFormatado = MascaraCrp.formatarCrp(atual.crp)

            val nomeBody = RequestBody.create(mediaType, atual.nome)
            val emailBody = RequestBody.create(mediaType, atual.email)
            val celularBody = RequestBody.create(mediaType, atual.celular)
            val senhaBody = RequestBody.create(mediaType, atual.senha)
            val cpfBody = RequestBody.create(mediaType, atual.cpf)
            val crpBody = RequestBody.create(mediaType, crpFormatado)
            val instBody = if (atual.instituicaoClinica.isNotBlank()) RequestBody.create(mediaType, atual.instituicaoClinica) else null
            val espBody = RequestBody.create(mediaType, espJson)

            RetrofitFactory().getProfissionalService().cadastrarProfissional(
                nomeBody, emailBody, celularBody, senhaBody, cpfBody, crpBody, instBody, espBody, idGoogleBody, fotoAvatarBody
            ).enqueue(object : Callback<JsonObject> {
                override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                    val json = if (response.isSuccessful) {
                        response.body()
                    } else {
                        val errorStr = response.errorBody()?.string()
                        if (!errorStr.isNullOrBlank()) {
                            try { JsonParser().parse(errorStr).asJsonObject } catch (e: Exception) { null }
                        } else null
                    }

                    val isSuccess = response.isSuccessful || (json?.has("status") == true && json.get("status").asBoolean)
                    if (isSuccess) {
                        _uiState.value = estado.copy(isLoading = false, etapa = EtapaCadastro.EM_ANALISE)
                    } else {
                        val rawMsg = json?.get("message")?.asString ?: json?.get("erro")?.asString
                        val msg = ErrorTranslator.traduzirCadastro(rawMsg)
                        _uiState.value = estado.copy(isLoading = false, erroGeral = msg)
                    }
                }

                override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                    _uiState.value = estado.copy(
                        isLoading = false,
                        erroGeral = ErrorTranslator.traduzirCadastro(t.message)
                    )
                }
            })
        }
    }

    fun voltar(): Boolean {
        if (estado.etapa != EtapaCadastro.SENHA) return false
        _uiState.value = estado.copy(etapa = EtapaCadastro.DADOS_PESSOAIS, erroGeral = null)
        return true
    }

    fun reiniciar() {
        _uiState.value = CadastroUiState(especialidadesList = estado.especialidadesList)
    }
}
